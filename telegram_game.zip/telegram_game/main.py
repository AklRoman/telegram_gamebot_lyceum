import json
import logging
import random
import time

from telegram.ext import Application, filters
from telegram.ext import CommandHandler, MessageHandler, CallbackQueryHandler
from telegram.ext import ApplicationBuilder
from telegram import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton


def return_users_db():
    with open('users_db.json') as file:
        users_db = json.load(file)
        return users_db


def find_user(user_id):
    with open('users_db.json') as file:
        users_db = json.load(file)
        return users_db[user_id]


def write_stats_user(user_id, user_stats=None, first_meet=False):
    users_db = return_users_db()
    if first_meet:
        user_stats = dict()
        user_stats['current_place'] = 'start_page'
        user_stats['coins'] = '0'
        user_stats['fight'] = {"enemy_hp": "",
                               "HP": "100",
                               "armor_cf": "1",
                               "damage_cf": "1"}
        with open('inventory.json', 'w') as f:
            data = {user_id: {'Зелье такое вот (+15HP)': 0, 'Зелье сякое (+30HP)': 0, 'Ого какое зелье (+50HP)': 0,
                              'Ягоды (+5HP)': 0}}
            json.dump(data, f)

        with open('users.json', 'w') as f:
            data = {user_id: {'actual_markup': ''}}
            json.dump(data, f)

    users_db[user_id] = user_stats
    with open('users_db.json', mode='w') as file:
        json.dump(users_db, file)


async def send_message(update, request, text=None):
    if request == 'meeting':
        name = text[0]
        await update.message.reply_html(rf"Отлично, так и запишем! Проходи, {name}, будь как у себя дома!",
                                        reply_markup=tavern_keyboard)
    elif request == 'switch_game':
        await update.message.reply_html(rf"Выберите игру", reply_markup=switch_game_keyboard)

    elif request == 'fight':
        await update.message.reply_html(rf"Вы вернулись в бой", reply_markup=fight_keyboard)

    elif request == 'fight1':
        await update.message.reply_html(rf"Вы вышли из таверны и на вас накинулся разбойник",
                                        reply_markup=fight_keyboard)
    elif request == 'fight2':
        await update.message.reply_html(rf"Из кустов на вас вываливается здоровый кабан", reply_markup=fight_keyboard)

    elif request == 'fight3':
        await update.message.reply_html(f'На вас набежала стая крыс', reply_markup=fight_keyboard)

    elif request == 'fight4':
        await update.message.reply_html(f'На вас вышел старый гнолл', reply_markup=fight_keyboard)

    elif request == 'forest1':
        await update.message.reply_html(rf"Перед вами оказалось три тропы", reply_markup=forest_keyboard1)

    elif request == 'forest2':
        await update.message.reply_html(rf"Вы вышли на развилку", reply_markup=forest_keyboard2)

    elif request == 'forest3':
        await update.message.reply_html(rf"Вы вышли на развилку, слева от вас виднеется огонек",
                                        reply_markup=forest_keyboard1)

    elif request == 'forest4':
        await update.message.reply_html(rf"Вы вышли на развилку, справа от вас темный лес",
                                        reply_markup=forest_keyboard2)

    elif request == 'forest_berries':
        await update.message.reply_html(f"Перед вами ягодная поляна", reply_markup=berries_keyboard)

    elif request == 'forest_camp':
        await update.message.reply_html(f"Вы вышли к костру, рядом с которым лежит гитара",
                                        reply_markup=forest_camp)

    elif request == 'camping':
        await update.message.reply_html(f"Вы отдохнули и восстановили здоровье",
                                        reply_markup=next_stage)

    elif request == 'berry':
        new_berry = text[0]
        await update.message.reply_html(f'Вы собрали {new_berry} ягод', reply_markup=berries_keyboard)

    elif request == 'deal_damage_to_enemy':
        player_damage = text[0]
        await update.message.reply_html(
            f"Вы нанесли противнику {player_damage} урона")

    elif request == 'hp_enemy_stay':
        enemy_hp = text[0]
        await update.message.reply_html(
            f"У него осталось {enemy_hp} здоровья")

    elif request == 'hp_player_stay':
        player_hp = text[0]
        await update.message.reply_html(
            f"У вас осталось {player_hp} здоровья", reply_markup=fight_keyboard)

    elif request == 'enemy_killed':
        gold = text[0]
        await update.message.reply_html(
            f'Вы убили противника и получили {gold} золота\nВы можете продолжить свое приключение',
            reply_markup=next_stage)

    elif request == 'you_died':
        lost_gold = text[0]
        await update.message.reply_html(
            f'Вы были убили и потеряли {lost_gold} золота\nТеперь вы вернетесь в таверну', reply_markup=next_stage)

    elif request == 'escape':
        lost_gold = text[0]
        await update.message.reply_html(
            f'''Вам удалось сбежать, было потеряно {lost_gold} золота''', reply_markup=next_stage)

    elif request == 'no_escape':
        enemy_damage = text[0]
        await update.message.reply_html(
            f'''Вам не удалось сбежать и вы получили {enemy_damage} урона''')

    elif request == 'return_to_tavern':
        name = text[0]
        await update.message.reply_html(f'C возвращением, {name}! Ваше здоровье было восстановлено',
                                        reply_markup=tavern_keyboard)

    elif request == 'tavern':
        name = text[0]
        await update.message.reply_html(f'Располагайся, {name}! Будь как дома!',
                                        reply_markup=tavern_keyboard)

    elif request == 'start_game':
        await update.message.reply_html(f'Игра началась', reply_markup=no_keyboard)


BOT_TOKEN = '6127023664:AAEigfblCHAh3-j_m2RuYD7yJvLMJzJggTQ'

proxy_url = "socks5://user:pass@host:port"
app = ApplicationBuilder().token("TOKEN").proxy_url(proxy_url).build()
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.DEBUG)
logger = logging.getLogger(__name__)

places = {'tavern': [['Магазин', 'Мини-игры'], ['Покинуть таверну']],
          'forest1': [['Пойти прямо'], ['Пойти налево'], ['Пойти направо'], ['Инвентарь']],
          'forest2': [['Пойти налево'], ['Пойти направо'], ['Инвентарь']],
          'forest3': [['Пойти прямо'], ['Пойти налево'], ['Пойти направо'], ['Инвентарь']],
          'forest4': [['Пойти налево'], ['Пойти направо'], ['Инвентарь']],
          'forest_berries': [['Пойти налево', 'Пойти направо'], ['Собирать ягоды'], ['Инвентарь']],
          'forest_camp': [['Пойти обратно', 'Присесть у костра']], 'boss': [],
          'fight': [['Атаковать', 'Сбежать'], ['Инвентарь']], 'next_stage': [['Далее']],
          'switch_game': [['Мемо', 'Линии'], ['Назад']],
          'in_front_tavern': [['Зайти внутрь']], 'start_page': [['Идти к свету']], 'dialog_time': [[]]}

emoji_lst = ['🐗', '🌳', '☀', '☠', '👻', '💜', '🍎', '🐭',
             '🐍', '🐸', '🐞', '🕷️', '🦊', '🦄', '🌼', '🌸', '🍄',
             '🍀', '🍂', '🔥', '🏹', '🛡️', '🌑', '💧', '💡', '🌷',
             '🌾', '🐛', '🦅', '🐴', '🐊', '🐇', '🐺', '🦋',
             '💣', '🐾', '🐝', '🐒', '🐰', '🐢', '🦎', '🍓', '🐶',
             '🦜', '🐱', '🦁', '🍊', '🐐', '🕸️', '🌲', '🏵️']

circles = ['🟣', '🔵', '🟢', '🟡', '🟠', '🔴', '⚫']

forest_keyboard1 = ReplyKeyboardMarkup(places['forest1'], one_time_keyboard=True)
forest_keyboard2 = ReplyKeyboardMarkup(places['forest2'], one_time_keyboard=True)
forest_camp = ReplyKeyboardMarkup(places['forest_camp'], one_time_keyboard=True)
tavern_keyboard = ReplyKeyboardMarkup(places['tavern'], one_time_keyboard=True)
start_page_keyboard = ReplyKeyboardMarkup(places['start_page'], one_time_keyboard=True)
in_front_tavern_keyboard = ReplyKeyboardMarkup(places['in_front_tavern'], one_time_keyboard=True)
switch_game_keyboard = ReplyKeyboardMarkup(places['switch_game'], one_time_keyboard=True)
fight_keyboard = ReplyKeyboardMarkup(places['fight'], one_time_keyboard=True)
next_stage = ReplyKeyboardMarkup(places['next_stage'], one_time_keyboard=True)
berries_keyboard = ReplyKeyboardMarkup(places['forest_berries'], one_time_keyboard=True)
no_keyboard = ReplyKeyboardMarkup([[]], one_time_keyboard=True)

choice_size = [[InlineKeyboardButton('7*8', callback_data='7 8'), InlineKeyboardButton('5*6', callback_data='5 6'),
                InlineKeyboardButton('3*4', callback_data='3 4')]]
size_markup = InlineKeyboardMarkup(choice_size)

choice_product = [[InlineKeyboardButton('Зелье такое вот (+15HP)', callback_data='0 20'),
                   InlineKeyboardButton('Зелье сякое (+30HP)', callback_data='1 30'),
                   InlineKeyboardButton('Ого какое зелье (+50HP)', callback_data='2 40')], [
                      InlineKeyboardButton('Назад', callback_data='назад')]]
shop_markup = InlineKeyboardMarkup(choice_product)

dialog_in_game = ''


async def inventory(update, context):
    user = str(update.message.from_user.id)
    with open("users.json") as file:
        data = json.load(file)
    with open("inventory.json") as f:
        inv = json.load(f)
    try:
        inventory = inv[user]
    except Exception:
        inv[user] = {}
        for i in range(len(choice_product) - 1):
            for product in choice_product[i]:
                inv[user][product.text] = 0
        inventory = inv[user]
    data[user]['actual_markup'] = 'inventory_markup'
    inventory_markup = []
    text = 'В инвентаре ничего нет'
    nothing_is_found = True
    for item in inventory:
        if str(inventory[item]) != '0':
            if nothing_is_found:
                text = 'Доступные предметы\n'
                text += f'\n{item} --- {inventory[item]}'
                nothing_is_found = False
            else:
                text += f'\n{item} --- {inventory[item]}'
            inventory_markup.append([InlineKeyboardButton(item, callback_data=item)])
    with open("inventory.json", 'w') as file:
        json.dump(inv, file)
    with open("users.json", 'w') as file:
        json.dump(data, file)
    inventory_markup.append([InlineKeyboardButton('Назад', callback_data='назад')])
    await update.message.reply_text(
        text=text, reply_markup=InlineKeyboardMarkup(inventory_markup))


async def shop(update, context):
    user = str(update.message.from_user.id)
    name = find_user(user)['name']
    with open("users.json") as file:
        data = json.load(file)
    with open("inventory.json") as f:
        inv = json.load(f)
    try:
        assortment = data[user]['assortment']
    except Exception:
        assortment = {}
        for i in range(len(choice_product) - 1):
            for product in choice_product[i]:
                assortment[product.text] = product.callback_data.split(' ')[1]
        try:
            data[user]['assortment'] = assortment
        except Exception:
            data[user] = {'assortment': assortment}
    try:
        inventory = inv[user]
    except Exception:
        inv[user] = {}
        for i in range(len(choice_product) - 1):
            for product in choice_product[i]:
                inv[user][product.text] = 0
    data[user]['actual_markup'] = 'shop_markup'
    text = '\n'
    text += f'Зелье такое вот (+15HP) --------------------- 20 золота\n' \
            f'Зелье сякое (+30HP) --------------------------- 30 золота\n' \
            f'Ого какое зелье (+50HP) --------------------- 40 золота\n'
    with open("users.json", 'w') as file:
        json.dump(data, file)
    with open("inventory.json", 'w') as file:
        json.dump(inv, file)
    await update.message.reply_text(
        text=f"Приветствуем вас в нашем магазинчике, {name}\nУ вас есть {find_user(user)['coins']} золота\n\n"
             f"В нашем ассортименте:{text}\nКупить:",
        reply_markup=shop_markup)


async def start_lines_game(update, context):
    user = str(update.message.from_user.id)
    lines_pole = [['⬜' for _ in range(7)] for __ in range(7)]
    free = [[i, j] for i in range(7) for j in range(7)]
    print(free)
    for i in range(3):
        x, y = free[random.randint(0, len(free) - 1)]
        lines_pole[x][y] = circles[random.randint(0, 6)]
        free.remove([x, y])
    with open("users.json") as file:
        data = json.load(file)
    try:
        data[user]['actual_markup'] = 'line_markup'
    except Exception:
        data[user] = {'actual_markup': 'line_markup'}
    data[user]['lines_pole'] = lines_pole
    data[user]['free_cells'] = free
    data[user]['steps'] = 0
    data[user]['score'] = 0
    with open("users.json", 'w') as file:
        json.dump(data, file)
    await update.message.reply_text(text='Игра в линии', reply_markup=InlineKeyboardMarkup(
        [[InlineKeyboardButton(lines_pole[i][j], callback_data=str(i) + str(j))
          for i in range(len(lines_pole[j]))] for j in range(len(lines_pole))]))


async def start_memory_game(update, context):
    user = str(update.message.from_user.id)
    with open("users.json") as file:
        data = json.load(file)
    try:
        data[user]['actual_markup'] = 'size_markup'

    except Exception:
        data[user] = {'actual_markup': 'size_markup'}
    data[user]['mistakes'] = 0
    data[user]['open_count'] = 0
    data[user]['open_now'] = []
    with open("users.json", 'w') as file:
        json.dump(data, file)
    await update.message.reply_text(text='Выберите размер поля', reply_markup=size_markup)


async def button(update, context):
    """Parses the CallbackQuery and updates the message text."""
    query = update.callback_query

    await query.answer()
    user = str(query.from_user.id)
    with open("users.json", "r") as file:
        f = file.read()
        data = json.loads(f)

    with open("inventory.json") as file:
        inv = json.load(file)

    user_statistic = find_user(user)
    user_money = int(user_statistic['coins'])

    actual_markup = data[user]['actual_markup']
    if actual_markup == 'reply_markup':
        await memory_card(update, context)

    elif actual_markup == 'size_markup':
        x, y = int(query.data.split(' ')[0]), int(query.data.split(' ')[-1])
        with open("users.json") as file:
            data = json.load(file)
        data[user]['map_size'] = x * y
        with open("users.json", 'w') as file:
            json.dump(data, file)
        await generate_memory_map(update, context, x, y)

    elif actual_markup == 'line_markup':
        x, y = int(query.data[0]), int(query.data[-1])
        await change_line_pole(update, context, x, y)

    elif actual_markup == 'shop_markup':
        if user_statistic['current_place'] == 'shop':
            if query.data == 'назад':
                user_statistic['current_place'] = 'tavern'
                await send_message(query, 'tavern', [user_statistic['name']])
                write_stats_user(user, user_statistic)
                await query.edit_message_reply_markup()

            else:
                num, to_pay = int(query.data.split(' ')[0]), int(query.data.split(' ')[1])
                if user_money < to_pay:
                    await query.edit_message_text(
                        text=f'{query.message.text[:264]}\n'
                             f'Не хватает {abs(to_pay - user_money)} чтобы купить {choice_product[0][num].text}!',
                        reply_markup=shop_markup)
                else:
                    user_money -= to_pay
                    user_statistic['coins'] = user_money
                    write_stats_user(user, user_statistic)
                    inv[user][choice_product[0][num].text] = int(inv[user][choice_product[0][num].text]) + 1
                    await query.edit_message_text(
                        text=f'{query.message.text[:264]}\n'
                             f'Поздравляем с покупкой {choice_product[0][num].text}!',
                        reply_markup=shop_markup)

    elif actual_markup == 'inventory_markup':
        user_statistic = find_user(user)
        if query.data == 'назад':
            user_statistic['current_place'] = user_statistic['next_place2']
            write_stats_user(user, user_statistic)
            await send_message(query, user_statistic['current_place'])
            await query.edit_message_reply_markup()

        else:
            item = query.data
            k = int(inv[user][item])
            health_points = user_statistic['fight']['HP']
            if item == 'Зелье такое вот (+15HP)':
                health_points = int(health_points) + 15

            elif item == 'Зелье сякое (+30HP)':
                health_points = int(health_points) + 30

            elif item == 'Ого какое зелье (+50HP)':
                health_points = int(health_points) + 50

            elif item == 'Ягоды (+5HP)':
                health_points = int(health_points) + 5

            if health_points > 100:
                health_points = 100

            user_statistic['fight']['HP'] = health_points
            write_stats_user(user, user_statistic)

            inv[user][item] = k - 1
            with open("inventory.json", 'w') as file:
                json.dump(inv, file)

            inventory_markup = []
            text = 'В инвентаре ничего нет'
            nothing_is_found = True
            for item in inv[user]:
                if str(inv[user][item]) != '0':
                    if nothing_is_found:
                        text = 'Доступные предметы\n'
                        text += f'\n{item} --- {inv[user][item]}'
                        nothing_is_found = False
                    else:
                        text += f'\n{item} --- {inv[user][item]}'
                    inventory_markup.append([InlineKeyboardButton(item, callback_data=item)])
            inventory_markup.append([InlineKeyboardButton('Назад', callback_data='назад')])

            await query.edit_message_text(
                text=f'{text}\n\nТеперь у вас {health_points} здоровья',
                reply_markup=InlineKeyboardMarkup(inventory_markup))

    with open("inventory.json", 'w') as file:
        json.dump(inv, file)


async def change_line_pole(update, context, x, y):
    with open("users.json") as file:
        data = json.load(file)
    query = update.callback_query
    user = str(query.from_user.id)
    lines_pole = data[user]['lines_pole']
    free = data[user]['free_cells']
    steps = data[user]['steps']
    score = data[user]['score']
    if lines_pole[x][y] in circles:
        data[user]['active_line_circle'] = x, y
    else:
        if data[user].get('active_line_circle'):
            old_x, old_y = data[user]['active_line_circle']
            if try_move(update, old_x, old_y, x, y):
                steps += 1
                lines_pole[x][y] = lines_pole[old_x][old_y]
                free.remove([x, y])
                lines_pole[old_x][old_y] = '⬜'
                data[user]['lines_pole'] = lines_pole
                data[user]['free_cells'] = free
                await query.edit_message_text(text=f'Игра в линии\nХодов :{steps}',
                                              reply_markup=InlineKeyboardMarkup(
                                                  [[InlineKeyboardButton(lines_pole[i][j],
                                                                         callback_data=str(i) + str(j))
                                                    for i in range(len(lines_pole[j]))] for j in
                                                   range(len(lines_pole))]))
                for_del = find_full_lines(lines_pole, x, y)
                if for_del:
                    for item in for_del:
                        i, j = item
                        lines_pole[i][j] = '⬜'
                        free.append([i, j])
                        score += 2
                    await query.edit_message_text(text=f'Игра в линии\nХодов :{steps}',
                                                  reply_markup=InlineKeyboardMarkup(
                                                      [[InlineKeyboardButton(lines_pole[i][j],
                                                                             callback_data=str(i) + str(j))
                                                        for i in range(len(lines_pole[j]))] for j in
                                                       range(len(lines_pole))]))
                    free.append([old_x, old_y])
                elif len(free) >= 3:
                    new_balls = []
                    i = 0
                    while i < 3 and free:
                        x, y = free[random.randint(0, len(free) - 1)]
                        lines_pole[x][y] = circles[random.randint(0, 6)]
                        free.remove([x, y])
                        new_balls.append([x, y])
                        i += 1
                    await query.edit_message_text(text=f'Игра в линии\nХодов :{steps}',
                                                  reply_markup=InlineKeyboardMarkup(
                                                      [[InlineKeyboardButton(lines_pole[i][j],
                                                                             callback_data=str(i) + str(j))
                                                        for i in range(len(lines_pole[j]))] for j in
                                                       range(len(lines_pole))]))
                    for it in new_balls:
                        x, y = it
                        for_del = find_full_lines(lines_pole, x, y)
                        if for_del:
                            for item in for_del:
                                i, j = item
                                lines_pole[i][j] = '⬜'
                                free.append([i, j])
                                score += 2
                            await query.edit_message_text(text=f'Игра в линии\nХодов :{steps}',
                                                          reply_markup=InlineKeyboardMarkup(
                                                              [[InlineKeyboardButton(lines_pole[i][j],
                                                                                     callback_data=str(i) + str(j))
                                                                for i in range(len(lines_pole[j]))] for j in
                                                               range(len(lines_pole))]))
                    free.append([old_x, old_y])

                else:
                    free.append([old_x, old_y])
                    for item in free:
                        x, y = item
                        lines_pole[x][y] = circles[random.randint(0, 6)]
                    await query.edit_message_text(text=f'\nВы набрали очков : {score}',
                                                  reply_markup=InlineKeyboardMarkup(
                                                      [[InlineKeyboardButton(lines_pole[i][j],
                                                                             callback_data=str(i) + str(j))
                                                        for i in range(len(lines_pole[j]))] for j in
                                                       range(len(lines_pole))]))

                    user_id = user
                    user_statistic = find_user(user_id)
                    user_statistic['current_place'] = 'switch_game'
                    write_stats_user(user_id, user_statistic)
                    await send_message(query, 'switch_game')

        else:
            data[user]['active_line_circle'] = []
        data[user]['steps'] = steps
        data[user]['score'] = score
        data[user]['free_cells'] = free
        data[user]['lines_pole'] = lines_pole

    with open("users.json", 'w') as file:
        json.dump(data, file)


def find_full_lines(pole, x, y):
    """Find all full lines starting by coordinates of ball"""
    if pole[x][y] not in circles:
        return
    current_color = pole[x][y]
    ball_for_delete = []
    minus_dx = x
    plus_dx = x + 1
    while minus_dx >= 0 and pole[minus_dx][y] == current_color:
        ball_for_delete.append((minus_dx, y))
        minus_dx -= 1
    while plus_dx < 7 and pole[plus_dx][y] == current_color:
        ball_for_delete.append((plus_dx, y))
        plus_dx += 1
    if len(ball_for_delete) >= 5:
        return ball_for_delete
    else:
        ball_for_delete.clear()
    minus_dy = y
    plus_dy = y + 1
    while minus_dy >= 0 and pole[x][minus_dy] == current_color:
        ball_for_delete.append((x, minus_dy))
        minus_dy -= 1
    while plus_dy < 7 and pole[x][plus_dy] == current_color:
        ball_for_delete.append((x, plus_dy))
        plus_dy += 1
    if len(ball_for_delete) >= 5:
        return ball_for_delete
    else:
        ball_for_delete.clear()
    minus_dx = x
    minus_dy = y
    plus_dx = x + 1
    plus_dy = y + 1
    while minus_dx >= 0 and minus_dy >= 0 and pole[minus_dx][minus_dy] == current_color:
        ball_for_delete.append((minus_dx, minus_dy))
        minus_dx -= 1
        minus_dy -= 1
    while plus_dx < 7 and plus_dy < 7 and pole[plus_dx][plus_dy] == current_color:
        ball_for_delete.append((plus_dx, plus_dy))
        plus_dx += 1
        plus_dy += 1
    if len(ball_for_delete) >= 5:
        return ball_for_delete
    else:
        ball_for_delete.clear()
    minus_dx = x
    plus_dy = y
    while minus_dx >= 0 and plus_dy < 7 and pole[minus_dx][plus_dy] == current_color:
        ball_for_delete.append((minus_dx, plus_dy))
        minus_dx -= 1
        plus_dy += 1
    plus_dx = x + 1
    minus_dy = y - 1
    while plus_dx < 7 and minus_dy >= 0 and pole[plus_dx][minus_dy] == current_color:
        ball_for_delete.append((plus_dx, minus_dy))
        plus_dx += 1
        minus_dy -= 1
    if len(ball_for_delete) >= 5:
        return ball_for_delete
    else:
        return


def try_move(update, start_x, start_y, end_x, end_y):
    with open("users.json") as file:
        data = json.load(file)
    query = update.callback_query
    user = str(query.from_user.id)
    lines_pole = data[user]['lines_pole']
    if lines_pole[end_x][end_y] in circles or lines_pole[start_x][start_y] not in circles:
        return False
    queue = []
    visited_cells = []
    queue.append((start_x, start_y))
    while len(queue) != 0:
        coordinates = queue.pop(0)
        if coordinates[0] < 0 or coordinates[0] >= 7 or coordinates[1] < 0 or coordinates[1] >= 7:
            continue
        if (coordinates != (start_x, start_y) and lines_pole[coordinates[0]][coordinates[1]] in circles) \
                or (coordinates[0], coordinates[1]) in visited_cells:
            continue
        if coordinates[0] == end_x and coordinates[1] == end_y:
            return True
        visited_cells.append((coordinates[0], coordinates[1]))
        for dy in range(-1, 2):
            for dx in range(-1, 2):
                if dx != 0 and dy != 0:
                    continue
                else:
                    queue.append((coordinates[0] + dx, coordinates[1] + dy))
    return False


async def memory_card(update, context):  # обработка и изменения поля
    end = False
    query = update.callback_query
    user = str(query.from_user.id)
    x, y = int(query.data[0]), int(query.data[1])
    with open("users.json", "r") as file:
        f = file.read()
    data = json.loads(f)

    cards = data[user]['cards']
    open_cards = data[user]['open_cards']
    cards[y][x] = str(open_cards[y][x])

    mistakes = data[user]['mistakes']
    await query.edit_message_text(text=f"!Игра в память!\n"
                                       f"Ошибок сделано: {mistakes}\n_________________________________",
                                  reply_markup=InlineKeyboardMarkup(
                                      [[InlineKeyboardButton(cards[j][i], callback_data=str(i) + str(j))
                                        for i in range(len(cards[j]))] for j in range(len(cards))]))
    open_now = data[user]['open_now']
    if not open_now:
        data[user]['open_now'] = x, y

    else:
        if open_cards[open_now[1]][open_now[0]] != open_cards[y][x]:
            cards[y][x] = '🔳'
            cards[open_now[1]][open_now[0]] = '🔳'

            data[user]['mistakes'] += 1
            time.sleep(0.5)  # это надо чтобы пользователь успел запомнить карточку перед ее закрытием

            await query.edit_message_text(
                text=f"!Игра в память!\n"
                     f"Ошибок сделано: {mistakes}\n_________________________________",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton(cards[j][i], callback_data=str(i) + str(j))
                      for i in range(len(cards[j]))] for j in range(len(cards))]))
        else:
            with open("users.json") as file:
                data = json.load(file)
            map_size = data[user]['map_size']
            open_count = data[user]['open_count'] + 2
            data[user]['open_count'] = open_count
            if open_count == map_size:
                if mistakes < map_size:
                    await query.edit_message_text(
                        text=f"Вы выиграли\n"
                             f"Очков прибавлено: {map_size - mistakes}\n",
                        reply_markup=InlineKeyboardMarkup(
                            [[InlineKeyboardButton(cards[j][i], callback_data=str(i) + str(j))
                              for i in range(len(cards[j]))] for j in range(len(cards))]))

                else:
                    await query.edit_message_text(
                        text=f"Вы допустили слишком много ошибок\n"
                             f"Очков прибавлено:0\n_________________________________",
                        reply_markup=InlineKeyboardMarkup(
                            [[InlineKeyboardButton(cards[j][i], callback_data=str(i) + str(j))
                              for i in range(len(cards[j]))] for j in range(len(cards))]))

                end = True

        data[user]['open_now'] = []
    data[user]['cards'] = cards
    with open("users.json", 'w') as file:
        json.dump(data, file)

    if end:
        user_id = user
        user_statistic = find_user(user_id)
        user_statistic['current_place'] = 'switch_game'
        write_stats_user(user_id, user_statistic)
        await send_message(query, 'switch_game')


async def generate_memory_map(update, context, x, y):  # генерация поля из эмодзи
    query = update.callback_query
    user = str(query.from_user.id)
    emoji_one = random.sample(emoji_lst, x * y // 2)
    emoji_two = emoji_one.copy()
    random.shuffle(emoji_two)
    open_cards = []
    for j in range(y):
        s = []
        for i in range(x):
            if j * x + i + 1 <= x * y // 2:
                s.append(emoji_one[j * x + i])
            else:
                s.append(emoji_two[j * x + i - x * y // 2])
        open_cards.append(s)
    cards = [['🔳' for _ in range(x)] for __ in range(y)]
    with open("users.json") as file:
        data = json.load(file)
    data[user]['actual_markup'] = 'reply_markup'
    data[user]['open_cards'] = open_cards
    data[user]['cards'] = cards
    with open("users.json", 'w') as file:
        json.dump(data, file)
    await query.edit_message_text("!Игра в память!\n"
                                  "Ошибок сделано:\n_________________________________",
                                  reply_markup=InlineKeyboardMarkup(
                                      [[InlineKeyboardButton(cards[j][i], callback_data=str(i) + str(j))
                                        for i in range(len(cards[j]))] for j in range(len(cards))]))


async def action(update, context):
    global dialog_in_game
    changed = False

    user_id = str(update.message.from_user.id)
    user_statistic = find_user(user_id)

    current_place = user_statistic['current_place']

    current_markup_elements = places[current_place]
    current_keyboard_elements = list()
    for el in current_markup_elements:
        for butt in el:
            current_keyboard_elements.append(butt)

    if dialog_in_game:
        if dialog_in_game == 'meeting':
            dialog_in_game = False
            name = update.message.text
            user_statistic['current_place'] = 'tavern'
            user_statistic['name'] = name
            await send_message(update, 'meeting', [name])
        changed = True

    elif update.message.text in current_keyboard_elements:

        if current_place == 'tavern':
            if update.message.text == 'Магазин':
                user_statistic['current_place'] = 'shop'
                await shop(update, context)

            elif update.message.text == 'Мини-игры':
                user_statistic['current_place'] = 'switch_game'
                await send_message(update, 'switch_game')

            elif update.message.text == 'Покинуть таверну':
                if random.randint(1, 100) <= 10:
                    user_statistic['next_place'] = 'forest1'
                    user_statistic['current_place'] = 'fight'
                    user_statistic['fight']['enemy_hp'] = '100'
                    await send_message(update, 'fight1')

                else:
                    user_statistic['current_place'] = 'forest1'
                    await send_message(update, 'forest1')

        elif current_place == 'switch_game':
            if update.message.text == 'Мемо':
                user_statistic['current_place'] = 'game'
                await send_message(update, 'start_game')
                await start_memory_game(update, context)

            elif update.message.text == 'Линии':
                user_statistic['current_place'] = 'game'
                await send_message(update, 'start_game')
                await start_lines_game(update, context)

            elif update.message.text == 'Назад':
                user_statistic['current_place'] = 'tavern'
                await send_message(update, 'tavern', [user_statistic['name']])

        elif current_place == 'forest1':
            if update.message.text == 'Пойти налево':
                user_statistic['current_place'] = 'tavern'
                user_statistic['fight']['HP'] = '100'
                await send_message(update, 'return_to_tavern', [user_statistic['name']])

            elif update.message.text == 'Пойти направо':
                user_statistic['current_place'] = 'forest2'
                await send_message(update, 'forest2')

            elif update.message.text == 'Пойти прямо':
                user_statistic['current_place'] = 'forest_berries'
                await send_message(update, 'forest_berries')

            elif update.message.text == 'Инвентарь':
                user_statistic['next_place2'] = user_statistic['current_place']
                user_statistic['current_place'] = 'inventory'
                await inventory(update, context)

        elif current_place == 'forest_berries':
            if update.message.text == 'Пойти налево':
                user_statistic['current_place'] = 'forest1'
                await send_message(update, 'forest1')

            elif update.message.text == 'Пойти направо':
                if random.randint(1, 100) <= 40:
                    user_statistic['next_place'] = 'forest2'
                    user_statistic['current_place'] = 'fight'
                    user_statistic['fight']['enemy_hp'] = '50'
                    await send_message(update, 'fight2')

                else:
                    user_statistic['current_place'] = 'forest2'
                    await send_message(update, 'forest2')

            elif update.message.text == 'Собирать ягоды':
                new_berry = random.randint(1, 3)
                with open('inventory.json') as f:
                    file = json.load(f)
                    file[user_id]['Ягоды (+5HP)'] = int(file[user_id]['Ягоды (+5HP)']) + new_berry

                with open("inventory.json", 'w') as f:
                    json.dump(file, f)

                await send_message(update, 'berry', [new_berry])

            elif update.message.text == 'Инвентарь':
                user_statistic['next_place2'] = user_statistic['current_place']
                user_statistic['current_place'] = 'inventory'
                await inventory(update, context)

        elif current_place == 'forest2':
            if update.message.text == 'Пойти налево':
                if random.randint(1, 100) <= 15:
                    user_statistic['next_place'] = 'forest1'
                    user_statistic['current_place'] = 'fight'
                    user_statistic['fight']['enemy_hp'] = '30'
                    await send_message(update, 'fight3')

                else:
                    user_statistic['current_place'] = 'forest1'
                    await send_message(update, 'forest1')

            elif update.message.text == 'Пойти направо':
                user_statistic['current_place'] = 'forest3'
                await send_message(update, 'forest3')

            elif update.message.text == 'Инвентарь':
                user_statistic['next_place2'] = user_statistic['current_place']
                user_statistic['current_place'] = 'inventory'
                await inventory(update, context)

        elif current_place == 'forest3':
            if update.message.text == 'Пойти налево':
                user_statistic['current_place'] = 'forest_camp'
                await send_message(update, 'forest_camp')

            elif update.message.text == 'Пойти направо':
                user_statistic['current_place'] = 'forest2'
                await send_message(update, 'forest2')

            elif update.message.text == 'Пойти прямо':
                if random.randint(1, 100) <= 40:
                    user_statistic['next_place'] = 'forest4'
                    user_statistic['current_place'] = 'fight'
                    user_statistic['fight']['enemy_hp'] = '50'
                    await send_message(update, 'fight2')

                else:
                    user_statistic['current_place'] = 'forest4'
                    await send_message(update, 'forest4')

            elif update.message.text == 'Инвентарь':
                user_statistic['next_place2'] = user_statistic['current_place']
                user_statistic['current_place'] = 'inventory'
                await inventory(update, context)

        elif current_place == 'forest_camp':
            if update.message.text == 'Пойти обратно':
                user_statistic['current_place'] = 'forest3'
                await send_message(update, 'forest3')

            elif update.message.text == 'Присесть у костра':
                user_statistic['next_place'] = 'forest_camp'
                user_statistic['current_place'] = 'next_stage'
                user_statistic['fight']['HP'] = '100'
                await send_message(update, 'camping')

        elif current_place == 'forest4':
            if update.message.text == 'Пойти налево':
                user_statistic['current_place'] = 'forest3'
                await send_message(update, 'forest3')

            elif update.message.text == 'Пойти направо':
                user_statistic['next_place'] = 'forest4'
                user_statistic['current_place'] = 'fight'
                user_statistic['fight']['enemy_hp'] = '150'
                await send_message(update, 'fight4')

            elif update.message.text == 'Инвентарь':
                user_statistic['next_place2'] = user_statistic['current_place']
                user_statistic['current_place'] = 'inventory'
                await inventory(update, context)

        elif current_place == 'fight':
            if update.message.text == 'Атаковать':
                player_damage = random.randint(10, 15) * int(user_statistic['fight']['damage_cf'])
                enemy_hp = int(user_statistic['fight']['enemy_hp']) - player_damage
                await send_message(update, 'deal_damage_to_enemy', [player_damage])

                if enemy_hp <= 0:
                    user_statistic['current_place'] = 'next_stage'
                    gold = random.randint(3, 15)
                    user_statistic['coins'] = gold
                    await send_message(update, 'enemy_killed', [gold])

                else:
                    await send_message(update, 'hp_enemy_stay', [enemy_hp])
                    enemy_damage = random.randint(5, 20)
                    player_hp = int(user_statistic['fight']['HP']) - enemy_damage
                    if player_hp <= 0:
                        user_statistic['current_place'] = 'next_stage'
                        user_statistic['next_place'] = 'tavern'
                        player_hp = 100
                        lost_gold = random.randint(0, int(user_statistic['coins']))
                        user_statistic['coins'] = int(user_statistic['coins']) - lost_gold
                        await send_message(update, 'you_died', [lost_gold])

                    else:
                        await send_message(update, 'hp_player_stay', [player_hp])
                    user_statistic['fight']['HP'] = player_hp
                    user_statistic['fight']['enemy_hp'] = enemy_hp

            elif update.message.text == 'Сбежать':
                if random.randint(0, 100) <= 25:
                    user_statistic['current_place'] = 'next_stage'
                    lost_gold = random.randint(0, int(user_statistic['coins']) // 5)
                    await send_message(update, 'escape', [lost_gold])

                else:
                    enemy_damage = random.randint(10, 20)
                    user_statistic['fight']['HP'] = int(user_statistic['fight']['HP']) - enemy_damage

                    player_hp = int(user_statistic['fight']['HP']) - enemy_damage
                    if player_hp <= 0:
                        user_statistic['current_place'] = 'next_stage'
                        user_statistic['next_place'] = 'tavern'
                        player_hp = 100
                        user_statistic['fight']['HP'] = player_hp
                        lost_gold = random.randint(0, int(user_statistic['coins']))
                        user_statistic['coins'] = int(user_statistic['coins']) - lost_gold
                        await send_message(update, 'you_died', [lost_gold])

                    else:
                        await send_message(update, 'no_escape', [enemy_damage])
                        await send_message(update, 'hp_player_stay', [user_statistic['fight']['HP']])

            elif update.message.text == 'Инвентарь':
                user_statistic['next_place2'] = user_statistic['current_place']
                user_statistic['current_place'] = 'inventory'
                await inventory(update, context)

        elif current_place == 'next_stage':
            user_statistic['current_place'] = user_statistic['next_place']
            await send_message(update, user_statistic['current_place'], [user_statistic['name']])

        elif current_place == 'start_page':
            if update.message.text == 'Идти к свету':
                user_statistic['current_place'] = 'in_front_tavern'
                await update.message.reply_html(rf"Вы стоите напротив двери в дом, из которого доносится веселый шум",
                                                reply_markup=in_front_tavern_keyboard)

        elif current_place == 'in_front_tavern':
            if update.message.text == 'Зайти внутрь':
                user_statistic['current_place'] = 'dialog_time'
                dialog_in_game = 'meeting'
                await update.message.reply_html(rf"Добро пожаловать в мою таверну, путник! Как твое имя?",
                                                reply_markup=no_keyboard)

        changed = True

    if changed:
        write_stats_user(user_id, user_statistic)


async def start(update, context):
    user_id = str(update.message.from_user.id)
    users_db = return_users_db()

    if user_id not in users_db:
        write_stats_user(user_id, first_meet=True)
        await update.message.reply_html(rf"Вы идете", reply_markup=start_page_keyboard)


def main():
    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler('start', start))
    action_handler = MessageHandler(filters.TEXT, action)
    application.add_handler(action_handler)
    application.add_handler(CallbackQueryHandler(button))
    application.run_polling()


if __name__ == '__main__':
    main()
